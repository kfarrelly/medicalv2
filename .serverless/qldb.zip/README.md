## seed data

node seed/insertDocument.js

## query data

node query/ScanTable.js

## find vehicles

node query/findVehicles.js 

## modify ownership

node modify/transferVehicleOwnership.js